/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stdio.h"
#include "IIC.h"
#include "inv_mpu.h"
#include "inv_mpu_dmp_motion_driver.h"
#include "mpu6050.h"
#include "step_motor.h"
#include "StewartMovement.h"
#include "printf.h"
#include "fytpi_math.h"
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

eul_angle stewart_angle = {0, 0, 0, 104.5, 0, 0};
float COPY_L1, COPY_L2, COPY_L3, COPY_L4, COPY_L5, COPY_L6;
int copy_NUM = 0, add_trans = 1;
uint8_t step_tran=1;

float pitch,roll,yaw; 		    //欧拉角
short aacx,aacy,aacz;			//加速度传感器原始数据
short gyrox,gyroy,gyroz;		//陀螺仪原始数据
float temp;//温度

uint8_t RxBuffer[50];
uint8_t TxBuffer[50];
//uint8_t BTx_Buffer[] ="Begin";
//uint8_t STx_Buffer[] ="Emergency";
uint32_t pwmValue = 300; // 按下按键实现蜂鸣器占空比30%
uint8_t Begin = 2;
uint8_t Replace = 0;
uint8_t mpu=1;
uint8_t StewartCount = 0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void UpdateStewartMovement(void); 
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{

  /* USER CODE BEGIN 1 */
	
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
	
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_TIM4_Init();
  MX_USART1_UART_Init();
  MX_TIM3_Init();
  /* USER CODE BEGIN 2 */
	MPU_Init();			//MPU6050初始化
	mpu_dmp_init();	//dmp初始化
	
	/* 电机初始化 */
	motor_Init(&step_motor_1);
	motor_Init(&step_motor_2);
	motor_Init(&step_motor_3);
	motor_Init(&step_motor_4);
	motor_Init(&step_motor_5);
	motor_Init(&step_motor_6);			
	motor_change(&step_motor_1, 1);
	motor_change(&step_motor_2, 1);
	motor_change(&step_motor_3, 1);
	motor_change(&step_motor_4, 1);
	motor_change(&step_motor_5, 1);
	motor_change(&step_motor_6, 1);
	
	HAL_UART_Receive_IT(&huart1,(uint8_t *)&RxBuffer,1);//开串口中断
	HAL_TIM_PWM_Start(&htim4, TIM_CHANNEL_3);           //开PWM
	HAL_TIM_Base_Start_IT(&htim3);  // 启动定时器并允许中断 
	
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
		 if(mpu==1)//MPU初始化（只初始化一次）
			{
				mpu=0;
				while(mpu_dmp_get_data(&pitch, &roll, &yaw));	     //必须要用while等待，才能读取成功
				printf("Initialization successful\r\n"); 
				temp=MPU_Get_Temperature();						             //得到温度信息
				printf("X:%.4f\t  Y:%.4f\t  Z:%.4f\t  Operating temperature:%.2f\r\n",roll,pitch,yaw,temp/100);//串口1输出采集信息
				HAL_Delay(1000);
				printf("---------------------------------------------------------------------------------------------------------------\r\n\r\n");  
				printf("Device ID:  %-8d\r\n", StewartCount);
				StewartCount++;
				//在平台解算得出的初始值上加减 				
				stewart_angle.target_alpha=pitch;
				stewart_angle.target_beta=roll;
				stewart_angle.target_gama=yaw;
				TR_stewart_movement(stewart_angle.target_alpha, stewart_angle.target_beta, stewart_angle.target_gama, stewart_angle.target_a, stewart_angle.target_b, stewart_angle.target_c, &TR_L1, &TR_L2, &TR_L3, &TR_L4, &TR_L5, &TR_L6);
				printf("---------------------------------------------------------------------------------------------------------------\r\n\r\n"); 
			}
		/* 串口发开机命令 */
		if(Begin==1)
		{
			printf("---------------------------------------------------------------------------------------------------------------\r\n"); 
			printf("Begin\r\n");
			HAL_GPIO_WritePin(GPIOE, GPIO_PIN_5, GPIO_PIN_RESET);//开启时开灯
			HAL_Delay(1000);
			UpdateStewartMovement();
			Begin=0;
		}
		else if(Begin==0)
		{
			printf("---------------------------------------------------------------------------------------------------------------\r\n"); 
			printf("Emergency\r\n"); 
			HAL_GPIO_WritePin(GPIOE, GPIO_PIN_5, GPIO_PIN_SET);//关灯
			__HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_3, 3000);//打开蜂鸣器
			HAL_Delay(2000);
			__HAL_TIM_SET_COMPARE(&htim4, TIM_CHANNEL_3, 0);//关闭蜂鸣器	
			/* 寻零 */
			eul_angle stewart_angle = {0, 0, 0, 104.5, 0, 0};
			TR_stewart_movement(stewart_angle.target_alpha, stewart_angle.target_beta, stewart_angle.target_gama, stewart_angle.target_a, stewart_angle.target_b, stewart_angle.target_c, &TR_L1, &TR_L2, &TR_L3, &TR_L4, &TR_L5, &TR_L6);
			Begin=2;
		}
		/* 反转加减提示灯 */
		if(Replace==1)
		{
			HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_5);
			HAL_Delay(1000);
			HAL_GPIO_TogglePin(GPIOB, GPIO_PIN_5);
			Replace=0;
		}
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.HSEPredivValue = RCC_HSE_PREDIV_DIV1;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLMUL = RCC_PLL_MUL9;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV2;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_2) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */

/* 按键中断 */
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
  if(GPIO_Pin==K1_Pin)//开启系统
	{ 
		Begin=1;
	}
	if(GPIO_Pin==K2_Pin)//急停系统
	{		
		Begin=0;
	}
	if(GPIO_Pin==K3_Pin)//反转加减
	{
		Replace = 1;//加减提示灯
		if (copy_NUM != 0)
		{
			if (add_trans)
					add_trans = 0;
			else
					add_trans = 1;			
			copy_NUM = 0;
		}
	}
}

/* 串口中断 */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)  
{
	if (huart->Instance == USART1) // 检测串口 USART1  
  {
		// 检查发送字母  
		if (RxBuffer[0] == 'A')       //如果上位机发送A，则alpha角
    {
			if (add_trans==1)
				stewart_angle.target_alpha += 0.50;
			else
				stewart_angle.target_alpha -= 0.50;
			copy_NUM = 1;			
    }
		else if (RxBuffer[0] == 'B')  // 如果上位机发送B,则beta角  
    {
			if (add_trans==1)
				stewart_angle.target_beta += 0.50;
			else
				stewart_angle.target_beta -= 0.50;
			copy_NUM = 2;	
		} 
		else if (RxBuffer[0] == 'G')  // 如果上位机发送G,则gama角   
    {
			if (add_trans==1)
				stewart_angle.target_gama += 0.50;
			else
				stewart_angle.target_gama -= 0.50;
			copy_NUM = 3;	
		}
		else if (RxBuffer[0] == 'X')  // 如果上位机发送X,则x轴平移   
    {
			if (add_trans==1)
				stewart_angle.target_a += 1.50;
			else
				stewart_angle.target_a -= 1.50;
			copy_NUM = 4;	
		}
		else if (RxBuffer[0] == 'Y')  // 如果上位机发送Y,则y轴平移   
    {
			if (add_trans==1)
				stewart_angle.target_b += 1.50;
			else
				stewart_angle.target_b -= 1.50;
			copy_NUM = 5;	
		}
		else if (RxBuffer[0] == 'Z')  // 如果上位机发送Z,则z轴平移   
    {
			if (add_trans==1)
				stewart_angle.target_c += 1.50;
			else
				stewart_angle.target_c -= 1.50;
			copy_NUM = 6;	
		}
		/* 备份数据 */
		COPY_L1  = TR_L1;				
		COPY_L2  = TR_L2;
		COPY_L3  = TR_L3;
		COPY_L4  = TR_L4;
		COPY_L5  = TR_L5;
		COPY_L6  = TR_L6;
		printf("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\r\n\r\n");
		// 目标长度解算
		TR_stewart_movement(stewart_angle.target_alpha, stewart_angle.target_beta, stewart_angle.target_gama, stewart_angle.target_a, stewart_angle.target_b, stewart_angle.target_c, &TR_L1, &TR_L2, &TR_L3, &TR_L4, &TR_L5, &TR_L6);			
		HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_SET);			// 	关闭过长or短保护提示灯
		// 过长or短保护
		if (Protect_More_L < TR_L1 || Protect_More_L < TR_L2 || Protect_More_L < TR_L3 || Protect_More_L < TR_L4 || Protect_More_L < TR_L5 || Protect_More_L < TR_L6 
			|| Protect_Less_L > TR_L1 || Protect_Less_L > TR_L2 || Protect_Less_L > TR_L3 || Protect_Less_L > TR_L4 || Protect_Less_L > TR_L5 || Protect_Less_L > TR_L6)				
		{
			printf("+++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++++\r\n");
			printf("Error\r\n");
			Begin=0;
			TR_L1 = COPY_L1;		// 恢复数据
			TR_L2 = COPY_L2;
			TR_L3 = COPY_L3;
			TR_L4 = COPY_L4;
			TR_L5 = COPY_L5;
			TR_L6 = COPY_L6;
			if (copy_NUM == 1)										// 恢复设定值
				stewart_angle.target_alpha -= 0.50;
			else if (copy_NUM == 2)
				stewart_angle.target_beta -= 0.50;
			else if (copy_NUM == 3)
				stewart_angle.target_gama -= 0.50;
			else if (copy_NUM == 4)
				stewart_angle.target_a -= 1.5;
			else if (copy_NUM == 5)
				stewart_angle.target_b -= 1.5;
			else if (copy_NUM == 6)
				stewart_angle.target_c -= 1.5;
			HAL_GPIO_WritePin(GPIOB, GPIO_PIN_5, GPIO_PIN_RESET);			// 	打开过长or短保护提示灯
		}			
    // 继续接收  
    HAL_UART_Receive_IT(&huart1, (uint8_t *)&RxBuffer, 1);  
  }  
}
/* 定时器中断 */
void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)
{
	if(htim->Instance == TIM3)		//定时器3,定时时间10ms
	{
		motor_move(&step_motor_1, step_tran);				// 驱动电机旋转
		motor_move(&step_motor_2, step_tran);
		motor_move(&step_motor_3, step_tran);
		motor_move(&step_motor_4, step_tran);
		motor_move(&step_motor_5, step_tran);
		motor_move(&step_motor_6, step_tran);
		
		if (step_tran)
			step_tran = 0;
		else
			step_tran = 1;
	}
  /* USER CODE END Callback 0 */
}
/* 更新六自由度平台各电机参数 */
void UpdateStewartMovement(void)  
{  
    printf("---------------------------------------------------------------------------------------------------------------\r\n\r\n");  
    printf("Device ID:  %-8d\r\n", StewartCount);  
    
    // 运动解算得到六支柱长度  
    stewart_movement(&pitch, &roll, &yaw, a, b, c, &L1, &L2, &L3, &L4, &L5, &L6);  
    StewartCount++;  

    // 更新每根支柱的电机状态  
    // L1  
    if (absFloat(TR_L1 - L1) > Allowable_error)  
    {  
        if (TR_L1 > L1)  
            motor_change(&step_motor_1, 1);  
        else  
            motor_change(&step_motor_1, 0);  
    }  
    else  
        motor_stop(&step_motor_1);  

    // L2  
    if (absFloat(TR_L2 - L2) > Allowable_error)  
    {  
        if (TR_L2 > L2)  
            motor_change(&step_motor_2, 1);  
        else  
            motor_change(&step_motor_2, 0);  
    }  
    else  
        motor_stop(&step_motor_2);  

    // L3  
    if (absFloat(TR_L3 - L3) > Allowable_error)  
    {  
        if (TR_L3 > L3)  
            motor_change(&step_motor_3, 1);  
        else  
            motor_change(&step_motor_3, 0);  
    }  
    else  
        motor_stop(&step_motor_3);  

    // L4  
    if (absFloat(TR_L4 - L4) > Allowable_error)  
    {  
        if (TR_L4 > L4)  
            motor_change(&step_motor_4, 1);  
        else  
            motor_change(&step_motor_4, 0);  
    }  
    else  
        motor_stop(&step_motor_4);  

    // L5  
    if (absFloat(TR_L5 - L5) > Allowable_error)  
    {  
        if (TR_L5 > L5)  
            motor_change(&step_motor_5, 1);  
        else  
            motor_change(&step_motor_5, 0);  
    }  
    else  
        motor_stop(&step_motor_5);  

    // L6  
    if (absFloat(TR_L6 - L6) > Allowable_error)  
    {  
        if (TR_L6 > L6)  
            motor_change(&step_motor_6, 1);  
        else  
            motor_change(&step_motor_6, 0);  
    }  
    else  
        motor_stop(&step_motor_6);  
}  
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
