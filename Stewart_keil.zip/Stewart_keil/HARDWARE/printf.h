#ifndef PRINTF_H
#define PRINTF_H

#include "stdio.h"

#endif
