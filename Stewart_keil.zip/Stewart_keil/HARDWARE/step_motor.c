#include "step_motor.h"

Motor step_motor_1 = {
	GPIOA,
	GPIO_PIN_5,
	GPIOA,
	GPIO_PIN_7,
	GPIOA,
	GPIO_PIN_6,
	1};

Motor step_motor_2 = {
	GPIOC,
	GPIO_PIN_4,
	GPIOC,
	GPIO_PIN_5,
	GPIOB,
	GPIO_PIN_0,
	1};

Motor step_motor_3 = {
	GPIOC,
	GPIO_PIN_1,
	GPIOC,
	GPIO_PIN_2,
	GPIOF,
	GPIO_PIN_10,
	1};	

Motor step_motor_4 = {
	GPIOC,
	GPIO_PIN_0,
	GPIOF,
	GPIO_PIN_8,
	GPIOF,
	GPIO_PIN_9,
	1};

Motor step_motor_5 = {
	GPIOF,
	GPIO_PIN_7,
	GPIOF,
	GPIO_PIN_5,
	GPIOF,
	GPIO_PIN_6,
	1};

Motor step_motor_6 = {
	GPIOF,
	GPIO_PIN_2,
	GPIOF,
	GPIO_PIN_3,
	GPIOF,
	GPIO_PIN_4,
	1};

//	uint16_t step_trasns;

/* ��ʼ���ò���������ŵ�ƽ */
void motor_Init(Motor* motor)
{
	HAL_GPIO_WritePin(motor->EnableGPIO, motor->EnablePin, GPIO_PIN_RESET);	
	HAL_GPIO_WritePin(motor->EN1GPIO, motor->EN1Pin, GPIO_PIN_SET);	
	HAL_GPIO_WritePin(motor->EN2GPIO, motor->EN2Pin, GPIO_PIN_RESET);	
}
	
/* �ı���״̬ */
void motor_change(Motor* motor, int IFforeward)
{
	HAL_GPIO_WritePin(motor->EnableGPIO, motor->EnablePin, GPIO_PIN_SET);			// 	�򿪵��ʹ������
	motor->foreward = IFforeward;
}

/* ���������������ת���� */
void motor_move(Motor* motor, uint8_t step_trasns)
{
	if (motor->foreward == 1)				// �쳤
	{
		if (step_trasns == 1)
		{
			HAL_GPIO_TogglePin(motor->EN1GPIO, motor->EN1Pin);
		}
		else
		{
			HAL_GPIO_TogglePin(motor->EN2GPIO, motor->EN2Pin);
		}
	}
	else														// ����
	{
		if (step_trasns == 1)
		{
			HAL_GPIO_TogglePin(motor->EN2GPIO, motor->EN2Pin);
		}
		else
		{
			HAL_GPIO_TogglePin(motor->EN1GPIO, motor->EN1Pin);
		}
	}
	
}

/* ���ֹͣ���� */
void motor_stop(Motor* motor)
{
	HAL_GPIO_WritePin(motor->EnableGPIO, motor->EnablePin, GPIO_PIN_RESET);			// �رյ��ʹ������
}
