#ifndef __STEP_MOTOR__
#define	__STEP_MOTOR__

#include <stdint.h>
#include <stm32f1xx_hal.h>

extern uint16_t step_trasns;

typedef struct  {
		GPIO_TypeDef* EnableGPIO;
		uint16_t EnablePin;
    GPIO_TypeDef* EN1GPIO;
		uint16_t EN1Pin;
		GPIO_TypeDef* EN2GPIO;
		uint16_t EN2Pin;
		int foreward;
}Motor;

extern Motor step_motor_1, step_motor_2, step_motor_3, step_motor_4, step_motor_5, step_motor_6;

void motor_Init(Motor* motor);
void motor_change(Motor* motor, int IFforeward);
void motor_move(Motor* motor, uint8_t step_trasns);
void motor_stop(Motor* motor);

#endif
