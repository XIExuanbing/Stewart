#include "StewartMovement.h"
#include "printf.h"
#include "light_matrix.h"
#include "math.h"
#include "fytpi_math.h"
#include "inv_mpu.h"
#include "inv_mpu_dmp_motion_driver.h"
#include "mpu6050.h"

Mat H;
Mat B;										// ��ƽ̨B�����λ��
Mat p1;										// ��ƽ̨p�����λ��
Mat p2;										// ����p�����λ��

float valB[4], valp1[4], valp2[4];
float alpha , beta, gama;
//float a = 104.5, b = 0 , c = 0;
float a , b , c ;
float L1, L2, L3, L4, L5, L6;
float TR_L1, TR_L2, TR_L3, TR_L4, TR_L5, TR_L6;
//int StewartCount = 0;


// stewartƽ̨�˶�����
void stewart_movement(float *pitch, float *roll, float *yaw, float a, float b, float c, float *L1, float *L2, float *L3, float *L4, float *L5, float *L6)
{
	alpha = *pitch, beta = *roll, gama = *yaw;
	a = 104.5, b = 0 , c = 0;
	printf("   alpha: %.4f\t", alpha);
	printf("   beta: %.4f\t        ", beta);
	printf("   gama: %.4f\t\r\n", gama);
	float valH[] = 
	{
		cos(alpha)*cos(beta), cos(alpha)*sin(beta)*sin(gama)-sin(alpha)*cos(gama), cos(alpha)*sin(beta)*cos(gama)+sin(alpha)*sin(gama), a,
		sin(alpha)*cos(beta), sin(alpha)*sin(beta)*sin(gama)+cos(alpha)*cos(gama), sin(alpha)*sin(beta)*cos(gama)-cos(alpha)*sin(gama), b,
		-sin(beta), cos(beta)*sin(gama), cos(beta)*cos(gama), c,
		0, 0, 0, 1
	};
	MatCreate(&H, 4, 4);
	MatSetVal(&H, valH);
	
	/*�ֱ�������˳���*/
	// L1
															// ��ƽ̨B�����λ��
	valB[0] = 0;
	valB[1] = Rb * sin(ThetaB);
	valB[2] =	Rb * cos(ThetaB);
	valB[3] =	1;
	MatCreate(&B, 4, 1);
	MatSetVal(&B, valB);
	
															// ��ƽ̨p�����λ��
	valp1[0] =	0;
	valp1[1] =	Rp * sin(60 - ThetaP);
	valp1[2] =	Rp * cos(60 - ThetaP);
	valp1[3] =	1;
	MatCreate(&p1, 4, 1);
  MatSetVal(&p1, valp1);
	
															// ����p�����λ��
	valp1[0] =	1;
	valp1[1] =	1;
	valp1[2] =	1;
	valp1[3] =	1;
	MatCreate(&p2, 4, 1);
	MatSetVal(&p2, valp2);
	MatMul(&H, &p1, &p2);
	*L1 = MatNorm(&B, &p2);
	printf("   L1: %.4f\t", *L1);
	
	// L2
															// ��ƽ̨B�����λ��
	valB[0] = 0;
	valB[1] = Rb * sin(120 - ThetaB);
	valB[2] =	Rb * cos(120 - ThetaB);
	valB[3] =	1;
	
	MatCreate(&B, 4, 1);
	MatSetVal(&B, valB);
	
															// ��ƽ̨p�����λ��

	valp1[0] =	0;
	valp1[1] =	Rp * sin(60 + ThetaP);
	valp1[2] =	Rp * cos(60 + ThetaP);
	valp1[3] =	1;

	MatCreate(&p1, 4, 1);
  MatSetVal(&p1, valp1);
	
															// ����p�����λ��
	MatMul(&H, &p1, &p2);
	*L2 = MatNorm(&B, &p2);
	printf("   L2: %.4f\t", *L2);
	
	// L3
															// ��ƽ̨B�����λ��
	valB[0] = 0;
	valB[1] = Rb * sin(120 + ThetaB);
	valB[2] =	Rb * cos(120 + ThetaB);
	valB[3] =	1;
	
	MatCreate(&B, 4, 1);
	MatSetVal(&B, valB);
	
															// ��ƽ̨p�����λ��

	valp1[0] =	0;
	valp1[1] =	Rp * sin(180 - ThetaP);
	valp1[2] =	Rp * cos(180 - ThetaP);
	valp1[3] =	1;

	MatCreate(&p1, 4, 1);
  MatSetVal(&p1, valp1);
	
															// ����p�����λ��
	MatMul(&H, &p1, &p2);
	*L3 = MatNorm(&B, &p2);
	printf("   L3: %.4f\t", *L3);
	
	// L4
															// ��ƽ̨B�����λ��
	valB[0] = 0;
	valB[1] = Rb * sin(240 - ThetaB);
	valB[2] =	Rb * cos(240 - ThetaB);
	valB[3] =	1;
	
	MatCreate(&B, 4, 1);
	MatSetVal(&B, valB);
	
															// ��ƽ̨p�����λ��

	valp1[0] =	0;
	valp1[1] =	Rp * sin(180 + ThetaP);
	valp1[2] =	Rp * cos(180 + ThetaP);
	valp1[3] =	1;

	MatCreate(&p1, 4, 1);
  MatSetVal(&p1, valp1);
	
															// ����p�����λ��
	MatMul(&H, &p1, &p2);
	*L4 = MatNorm(&B, &p2);
	printf("   L4: %.4f\t", *L4);
	
	// L5
															// ��ƽ̨B�����λ��
	valB[0] = 0;
	valB[1] = Rb * sin(240 + ThetaB);
	valB[2] =	Rb * cos(240 + ThetaB);
	valB[3] =	1;
	
	MatCreate(&B, 4, 1);
	MatSetVal(&B, valB);
	
															// ��ƽ̨p�����λ��

	valp1[0] =	0;
	valp1[1] =	Rp * sin(300 - ThetaP);
	valp1[2] =	Rp * cos(300 - ThetaP);
	valp1[3] =	1;

	MatCreate(&p1, 4, 1);
  MatSetVal(&p1, valp1);
	
															// ����p�����λ��
	MatMul(&H, &p1, &p2);
	*L5 = MatNorm(&B, &p2);
	printf("   L5: %.4f\t", *L5);
	
	// L6
															// ��ƽ̨B�����λ��
	valB[0] = 0;
	valB[1] = Rb * sin(360 - ThetaB);
	valB[2] =	Rb * cos(360 - ThetaB);
	valB[3] =	1;
	
	MatCreate(&B, 4, 1);
	MatSetVal(&B, valB);
	
															// ��ƽ̨p�����λ��

	valp1[0] =	0;
	valp1[1] =	Rp * sin(300 + ThetaP);
	valp1[2] =	Rp * cos(300 + ThetaP);
	valp1[3] =	1;

	MatCreate(&p1, 4, 1);
  MatSetVal(&p1, valp1);
	
															// ����p�����λ��
	MatMul(&H, &p1, &p2);
	*L6 = MatNorm(&B, &p2);
	printf("   L6: %.4f\t\r\n", *L6);
	
}


/* stewartƽ̨Ŀ��λ���˶����� */
void TR_stewart_movement(float alpha, float beta, float gama, float a, float b, float c, float *TR_L1, float *TR_L2, float *TR_L3, float *TR_L4, float *TR_L5, float *TR_L6)
{
	printf("TR_alpha: %.4f\t", alpha);
	printf("TR_beta: %.4f\t        ", beta);
	printf("TR_gama: %.4f\t\r\n", gama);
	
	float valH[] = 
	{
		cos(alpha)*cos(beta), cos(alpha)*sin(beta)*sin(gama)-sin(alpha)*cos(gama), cos(alpha)*sin(beta)*cos(gama)+sin(alpha)*sin(gama), a,
		sin(alpha)*cos(beta), sin(alpha)*sin(beta)*sin(gama)+cos(alpha)*cos(gama), sin(alpha)*sin(beta)*cos(gama)-cos(alpha)*sin(gama), b,
		-sin(beta), cos(beta)*sin(gama), cos(beta)*cos(gama), c,
		0, 0, 0, 1
	};

	MatCreate(&H, 4, 4);
	MatSetVal(&H, valH);

	// �ֱ�������˳���
	// L1
															// ��ƽ̨B�����λ��
	valB[0] = 0;
	valB[1] = Rb * sin(ThetaB);
	valB[2] =	Rb * cos(ThetaB);
	valB[3] =	1;
	MatCreate(&B, 4, 1);
	MatSetVal(&B, valB);
	
															// ��ƽ̨p�����λ��
	valp1[0] =	0;
	valp1[1] =	Rp * sin(60 - ThetaP);
	valp1[2] =	Rp * cos(60 - ThetaP);
	valp1[3] =	1;
	MatCreate(&p1, 4, 1);
  MatSetVal(&p1, valp1);
	
															// ����p�����λ��
	valp1[0] =	1;
	valp1[1] =	1;
	valp1[2] =	1;
	valp1[3] =	1;
	MatCreate(&p2, 4, 1);
	MatSetVal(&p2, valp2);
	MatMul(&H, &p1, &p2);
	*TR_L1 = MatNorm(&B, &p2);
	printf("TR_L1: %.4f\t", *TR_L1);
	
	// L2
															// ��ƽ̨B�����λ��
	valB[0] = 0;
	valB[1] = Rb * sin(120 - ThetaB);
	valB[2] =	Rb * cos(120 - ThetaB);
	valB[3] =	1;
	
	MatCreate(&B, 4, 1);
	MatSetVal(&B, valB);
	
															// ��ƽ̨p�����λ��

	valp1[0] =	0;
	valp1[1] =	Rp * sin(60 + ThetaP);
	valp1[2] =	Rp * cos(60 + ThetaP);
	valp1[3] =	1;

	MatCreate(&p1, 4, 1);
  MatSetVal(&p1, valp1);
	
															// ����p�����λ��
	MatMul(&H, &p1, &p2);
	*TR_L2 = MatNorm(&B, &p2);
	printf("TR_L2: %.4f\t", *TR_L2);
	
	// L3
															// ��ƽ̨B�����λ��
	valB[0] = 0;
	valB[1] = Rb * sin(120 + ThetaB);
	valB[2] =	Rb * cos(120 + ThetaB);
	valB[3] =	1;
	
	MatCreate(&B, 4, 1);
	MatSetVal(&B, valB);
	
															// ��ƽ̨p�����λ��

	valp1[0] =	0;
	valp1[1] =	Rp * sin(180 - ThetaP);
	valp1[2] =	Rp * cos(180 - ThetaP);
	valp1[3] =	1;

	MatCreate(&p1, 4, 1);
  MatSetVal(&p1, valp1);
	
															// ����p�����λ��
	MatMul(&H, &p1, &p2);
	*TR_L3 = MatNorm(&B, &p2);
	printf("TR_L3: %.4f\t", *TR_L3);
	
	// L4
															// ��ƽ̨B�����λ��
	valB[0] = 0;
	valB[1] = Rb * sin(240 - ThetaB);
	valB[2] =	Rb * cos(240 - ThetaB);
	valB[3] =	1;
	
	MatCreate(&B, 4, 1);
	MatSetVal(&B, valB);
	
															// ��ƽ̨p�����λ��

	valp1[0] =	0;
	valp1[1] =	Rp * sin(180 + ThetaP);
	valp1[2] =	Rp * cos(180 + ThetaP);
	valp1[3] =	1;

	MatCreate(&p1, 4, 1);
  MatSetVal(&p1, valp1);
	
															// ����p�����λ��
	MatMul(&H, &p1, &p2);
	*TR_L4 = MatNorm(&B, &p2);
	printf("TR_L4: %.4f\t", *TR_L4);
	
	// L5
															// ��ƽ̨B�����λ��
	valB[0] = 0;
	valB[1] = Rb * sin(240 + ThetaB);
	valB[2] =	Rb * cos(240 + ThetaB);
	valB[3] =	1;
	
	MatCreate(&B, 4, 1);
	MatSetVal(&B, valB);
	
															// ��ƽ̨p�����λ��

	valp1[0] =	0;
	valp1[1] =	Rp * sin(300 - ThetaP);
	valp1[2] =	Rp * cos(300 - ThetaP);
	valp1[3] =	1;

	MatCreate(&p1, 4, 1);
  MatSetVal(&p1, valp1);
	
															// ����p�����λ��
	MatMul(&H, &p1, &p2);
	*TR_L5 = MatNorm(&B, &p2);
	printf("TR_L5: %.4f\t", *TR_L5);
	
	// L6
															// ��ƽ̨B�����λ��
	valB[0] = 0;
	valB[1] = Rb * sin(360 - ThetaB);
	valB[2] =	Rb * cos(360 - ThetaB);
	valB[3] =	1;
	
	MatCreate(&B, 4, 1);
	MatSetVal(&B, valB);
	
															// ��ƽ̨p�����λ��

	valp1[0] =	0;
	valp1[1] =	Rp * sin(300 + ThetaP);
	valp1[2] =	Rp * cos(300 + ThetaP);
	valp1[3] =	1;

	MatCreate(&p1, 4, 1);
  MatSetVal(&p1, valp1);
	
															// ����p�����λ��
	MatMul(&H, &p1, &p2);
	*TR_L6 = MatNorm(&B, &p2);
	printf("TR_L6: %.4f\t\r\n", *TR_L6);
	
}
